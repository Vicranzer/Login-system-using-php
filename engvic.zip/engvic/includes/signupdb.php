<?php
require_once('connection.php');
if (isset($_POST['signup'])) {
		
	/*function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
	
		
	$fullnames=test_input($_POST["fullnames"]);    
	$username= test_input($_POST["username"]);
	$email= test_input($_POST["email"]);
	$password=test_input ($_POST["password"]);
	$password2=test_input($_POST["password2"]);*/
	
	
	if (empty($_POST['fullnames'])||empty($_POST['username'])||empty($_POST['email'])||empty($_POST['password'])||empty($_POST['password2'])) {
		header("location: ../signup.php?error= Please fill in the above fields ");
		exit();
	}
	else{
		$fullnames=mysqli_real_escape_string($conn,$_POST["fullnames"]);    
		$username= mysqli_real_escape_string($conn,$_POST["username"]);
		$email=mysqli_real_escape_string($conn,$_POST["email"]);
		$password=mysqli_real_escape_string($conn,$_POST["password"]);
		$password2=mysqli_real_escape_string($conn,$_POST["password2"]);
		
if (!preg_match("/^[a-zA-Z ]*$/",$fullnames)) {
  header("location: ../signup.php?error=Only letters and white space allowed");
exit();
}
		
		  
		
		  else{
			  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			header("location: ../signup.php?error=Invalid email format");
			exit();
		  }
			
				if($password!==$password2){
					header("location: ../signup.php?error=The passwords do not match");
					exit();
				}
				else{
					$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
				mysqli_query($conn, $sql);
				$sqlcreate = "CREATE TABLE IF NOT EXISTS newguests (fullnames VARCHAR(50) NOT NULL, username VARCHAR(50) NOT NULL, email VARCHAR(50) NOT NULL, pass VARCHAR(50) NOT NULL)";
				mysqli_query($conn, $sqlcreate);
			   
			   
				$sqlsearch="SELECT * FROM newguests WHERE username='".$username."'";
				$result=mysqli_query($conn,$sqlsearch);
				if(mysqli_fetch_assoc($result)){
					header("location: ../signup.php?error=The Username is already taken");
					exit();
				}
				else{
				$sqlsearch2="SELECT * FROM newguests WHERE email='".$email."'";
				$result2=mysqli_query($conn,$sqlsearch2);
				if(mysqli_fetch_assoc($result2)){
					header("location: ../signup.php?error=The Email is already taken");
					exit();
				}
				else{
					//$password=md5($password);
					$hashpwd=password_hash($password, PASSWORD_DEFAULT); 
					$sql = "INSERT INTO newguests (fullnames, username, email, pass) VALUES ('$fullnames', '$username','$email', '$hashpwd')";
					if (mysqli_query($conn, $sql)) { 
						header("location: ../login.php?error= Sign Up success");
						exit();
				} else {
					header("location: ../signup.php?error=Something went wrong please try again");
					exit();
				}    
				}
			  }
		  }
	}
	

	
		
}
	}

else{

	header("location: ../index.php");
	exit();

}
?>