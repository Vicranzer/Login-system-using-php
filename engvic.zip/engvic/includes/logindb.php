<?php
session_start();
require_once('connection.php');
if (isset($_POST['login'])) { 
	
	if (empty($_POST['username'])||empty($_POST['password'])) {
		header("location: ../login.php?error=Please fill in the above fields");
		exit();
	}
	
	else{
		$username=mysqli_real_escape_string($conn,$_POST['username']);
		$password=mysqli_real_escape_string($conn,$_POST['password']);
		

		$sql = "SELECT * FROM newguests WHERE username= '".$username."' OR email='".$username."'"; 
		$result = mysqli_query($conn, $sql); 
		
		if($row=mysqli_fetch_assoc($result)){
		  
		  $hashpassword= password_verify($password,$row['pass']);
		  
		  if($hashpassword==false){
			header("location: ../login.php?error=Incorrect username or password");
			
			exit();
		  }
		  else if($hashpassword==true){
			  
			
			$_SESSION ['username']=$row['username'];
			$_SESSION ['fullnames']=$row['fullnames'];
			
		   
			header("location: ../account.php?error=success");
			exit();
			  
		  }
		 
				 
		
		}
		else{
		  header("location: ../login.php?error=Please Sign up");
		  exit();
		}
		  
	  $conn->close();
	  
	}

}

	

else{
	
	header("location: ../index.php");
	exit();
}
?>