<?php
   
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname= "newusers";
   
    $conn = mysqli_connect($servername, $username, $password,$dbname);
    
    // Create connection
   

    
    

?>