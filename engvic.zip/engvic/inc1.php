
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.css">

    <title>Login System</title>
  </head>
  <body style="background: #CCC;">

    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
      <div class="container">
 <a href="index.php" class="navbar-brand"><h3>HOME</h3></a>
 <div class="collapse navbar-collapse">
  <ul class="nav navbar ml-auto">
   

    <?php
    session_start();
    if (isset($_SESSION['username']))
    {
echo '<form action="includes/logout.php" method="POST">
<li class="nav-item"><button type="submit" name="logout" class="btn btn-outline-light ml-3">Log Out</button></li>
</form>';

    }
    else{
echo'
<li class="nav-item"><a href="login.php" name="login" class="btn btn-outline-light ml-3">Log In</a></li>

<li class="nav-item"><a href="signup.php" name="signup" class="btn btn-outline-light ml-3">Sign Up</a></li>'
;
    }
    
    ?>
  </ul>
  
  </div>
    </div>

  </nav>
  
    <script src="js/bootstrap.js"></script>
  </body>
</html>