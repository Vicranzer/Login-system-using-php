</body>
<footer align="center">
        Copyright &copy; <span id="year"></span> 
         <script>
        var d= new Date();
        document.getElementById("year").innerHTML=d.getFullYear();
       </script>
        </footer>
</html>