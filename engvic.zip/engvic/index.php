<?php
require_once('inc1.php');
?>
<h4 class="display-4 text-center mt-5">Welcome to our official home page</h4>
<?php
require_once('foot.php')
?>