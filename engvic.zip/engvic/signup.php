<?php

require_once('inc1.php');
?>
<h4 class="display-4 text-center mt-5">Welcome to our official sign-up page</h4>
<div class="container">
	
<div class="row">
	<div class="col-lg-6 m-auto">
		<div class="card bg-light mt-3">
			<div class="card-title bg-primary text-white mt-3">
				<h3 class="text-center py-2">Sign-Up Form</h3>
			</div>
			
			<div class="card-body">
				<form action="includes/signupdb.php" method="POST">
				<input type="name" name="fullnames" placeholder="Enter your Full Names" class="form-control my-2">
				<input type="name" name="username" placeholder="Enter your username" class="form-control my-2">
				<input type="email" name="email" placeholder="Enter your email" class="form-control my-2">
				<input type="password" name="password" placeholder="Enter your password" class="form-control my-2">
				<input type="password" name="password2" placeholder="Re-enter your password" class="form-control my-2" >
				<button class="btn btn-success" name="signup">SIGN-UP</button>
				<a href="login.php">Already have an account?</a>
				<?php
				
				if(isset($_GET['error'])){
				?>
			<div class="alert alert-danger"><?php echo $_GET['error'] ?></div>
			<?php
			}				
?>
			
			
				
			</form>
			
			</div>
		</div>
	</div>
</div>
<?php
require_once('foot.php');
?>