<?php
require_once('inc1.php');
?>
<h4 class="display-4 text-center mt-5">Welcome to our official login page</h4>

<div class="container">
	
<div class="row">
	<div class="col-lg-6 m-auto">
		<div class="card bg-light mt-5">
			<div class="card-title bg-primary text-white mt-5">
			
				<h3 class="text-center py-2">Login Form</h3>
			</div>
			<div class="card-body">
				<form action="includes/logindb.php" method="POST">
				<input type="name" name="username" placeholder="Enter your username or email" class="form-control mb-2">
				
				<input type="password" name="password" placeholder="Enter your password" class="form-control mb-2">
				
				<button class="btn btn-success" name="login" class="pt-3">LOGIN</button>
				Don't have an account yet? <a href="signup.php">Create an account</a>
			</form>
			<?php
				if(isset($_GET['error'])){
				?>
			<div class="alert alert-danger"><?php echo $_GET['error'] ?></div>
			<?php
			}				
?>
			
				
				
				
		</div>
	</div>
</div>
</div>		
<?php
require_once('foot.php');
?>